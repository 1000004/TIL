package org.sys.bookstock.dto;

public class Book {
	private int d_num;
	private String d_title;
	private String d_athor;
	private int d_price;
	private String d_area;
	private int d_stock;
	public Book() {}
	//insert
	public Book(String d_title, String d_athor, int d_price, String d_area, int d_stock) {
		super();
		this.d_title = d_title;
		this.d_athor = d_athor;
		this.d_price = d_price;
		this.d_area = d_area;
		this.d_stock = d_stock;
	}
	//select
	public Book(int d_num, String d_title, String d_athor, int d_price, String d_area, int d_stock) {
		super();
		this.d_num = d_num;
		this.d_title = d_title;
		this.d_athor = d_athor;
		this.d_price = d_price;
		this.d_area = d_area;
		this.d_stock = d_stock;
	}
	public int getD_num() {
		return d_num;
	}
	public void setD_num(int d_num) {
		this.d_num = d_num;
	}
	public String getD_title() {
		return d_title;
	}
	public void setD_title(String d_title) {
		this.d_title = d_title;
	}
	public String getD_athor() {
		return d_athor;
	}
	public void setD_athor(String d_athor) {
		this.d_athor = d_athor;
	}
	public int getD_price() {
		return d_price;
	}
	public void setD_price(int d_price) {
		this.d_price = d_price;
	}
	public String getD_area() {
		return d_area;
	}
	public void setD_area(String d_area) {
		this.d_area = d_area;
	}
	public int getD_stock() {
		return d_stock;
	}
	public void setD_stock(int d_stock) {
		this.d_stock = d_stock;
	}
	@Override
	public String toString() {
		return "Book [d_num=" + d_num + ", d_title=" + d_title + ", d_athor=" + d_athor + ", d_price=" + d_price
				+ ", d_area=" + d_area + ", d_stock=" + d_stock + "]";
	}
}
