package org.sys.bookstock.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.sys.bookstock.dao.MySqlBookDao;
import org.sys.bookstock.dto.Book;
@Service
public class BookStockService {
	@Autowired
	private MySqlBookDao dao;
	
	public List<Book> getAll(){
		List<Book> list = dao.getAll();
		return list;
	}
	public int insert(Book book) {
		int result = dao.insert(book);
		return result;
	}
	public List<Book> findBook(String forWhat, String about_book){
		List<Book> list = null;
		if(forWhat.equals("num")) {
			list = dao.findByNum(about_book);
		}else {
			list = dao.findBytitle(about_book);
		}
		return list;
	}
	public int modify(Book book){
		int result = dao.modify( book);
		return result;
	}
	public int delete(Book book){
		int result = dao.delete( book);
		return result;
	}
}
