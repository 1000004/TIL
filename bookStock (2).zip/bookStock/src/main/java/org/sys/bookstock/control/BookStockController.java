package org.sys.bookstock.control;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.sys.bookstock.dto.Book;
import org.sys.bookstock.service.BookStockService;

@Controller
public class BookStockController {
	
	@Autowired
	private BookStockService service;
	
	@RequestMapping(value={"/","/getAll"})
	public String goMain(Model model) {
		List<Book> list = service.getAll();
		model.addAttribute("list", list);
		model.addAttribute("contentPage", "list.jsp");
		model.addAttribute("listSize", list.size());
		return "main";
	}
	@RequestMapping("/goInsert")
	public String goInsert(Model model) {
		
		model.addAttribute("contentPage", "insert.jsp");
		return "main";
	}
	@RequestMapping("/insert")
	public String insert(Book book) {
		System.out.println(book);
		service.insert(book);
		return "redirect:/getAll";
	}
	@RequestMapping("/goFind")
	public String goFind(Model model) {
		model.addAttribute("contentPage", "find.jsp");
		return "main";
	}
	@RequestMapping("/find")
	public String find(Model model, String forWhat, String about_book) {
		System.out.println(about_book);
		System.out.println(forWhat);
		List<Book> list = service.findBook(forWhat, about_book);
		model.addAttribute("list", list);
		model.addAttribute("contentPage", "findList.jsp");
		model.addAttribute("listSize", list.size());
		return "main";
	}
	@RequestMapping("/modify")
	public String modify(Book book) {
		service.modify(book);
		return "redirect:/getAll";
	}
	@RequestMapping("/delete")
	public String delete(Book book) {
		service.delete(book);
		return "redirect:/getAll";
	}
}
