package org.sys.bookstock.dao;

import java.sql.Connection;
import java.util.Vector;


import org.sys.bookstock.dto.Book;

public interface IBookStockDao {
	Connection connect();
	void disconnect(Connection con);
	int insert(Connection con, Book book);
	Vector<Book> getAll(Connection con);
	Vector<Book> findBytitle(Connection con, String key);
	Vector<Book> findByNum(Connection con, String d_num);
	int modify(Connection con, Book book);
	int delete(Connection con, Book book);
}
