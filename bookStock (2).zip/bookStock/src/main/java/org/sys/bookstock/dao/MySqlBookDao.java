package org.sys.bookstock.dao;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Vector;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.sys.bookstock.dto.Book;

@Repository
public class MySqlBookDao{
	@Autowired
	private JdbcTemplate jdbcTmp;

	public List<Book> getAll() {
		return jdbcTmp.query("SELECT * FROM books ORDER BY d_num", 
			new BookMapper());
	}
	
	public int insert(Book book) {
		return jdbcTmp.update("INSERT INTO books (d_title, d_athor, d_price, d_area, d_stock) VALUES (?,?,?,?,?)", 
					toEn(book.getD_title()), toEn(book.getD_athor()), book.getD_price(), toEn(book.getD_area()), book.getD_stock());
	}

	public List<Book> findBytitle(String key) {
		return jdbcTmp.query("SELECT * FROM books WHERE d_title LIKE ? ORDER BY d_num", 
			new BookMapper(), "%" + toEn(key) + "%");
	}

	public int modify(Book book) {
		return jdbcTmp.update("UPDATE books SET d_area = ?, d_stock = ? WHERE d_num = ?", 
				toEn(book.getD_area()), book.getD_stock(), book.getD_num());
	}

	public int delete(Book book) {
		return jdbcTmp.update("DELETE FROM books WHERE d_num = ?", 
			book.getD_num());
	}

	public List<Book> findByNum(String d_num) {
		return jdbcTmp.query("SELECT * FROM books WHERE d_num = ? ORDER BY d_num", 
			new BookMapper(), d_num);
	}

	public static String toEn(String str){
		try{
			str = new String(str.getBytes("euc_kr"),"8859_1");
		}catch(UnsupportedEncodingException e){
			e.printStackTrace();
		}
		return str;
	}
	public static String toKor(String str){
		try{
			str = new String(str.getBytes("8859_1"),"euc_kr");
		}catch(UnsupportedEncodingException e){
			e.printStackTrace();
		}
		return str;
	}
	
//	private Book getBook(ResultSet rs)throws SQLException{
//		Book doc = new Book(
//			rs.getInt("d_num"),
//			toKor(rs.getString("d_title")),
//			toKor(rs.getString("d_athor")),
//			rs.getInt("d_price"),
//			toKor(rs.getString("d_area")),
//			rs.getInt("d_stock")
//		);
//		return doc;
//	}
//	private void close(Statement stmt) {
//		try {
//			stmt.close();
//		}catch(Exception e) {}
//	}
//	private void close(ResultSet rs) {
//		try {
//			rs.close();
//		}catch (Exception e) {}
//	}
	class BookMapper implements RowMapper<Book>{
		
		@Override
		public Book mapRow(ResultSet rs, int rowNum) throws SQLException{
			return new Book(
					rs.getInt("d_num"),
					toKor(rs.getString("d_title")),
					toKor(rs.getString("d_athor")),
					rs.getInt("d_price"),
					toKor(rs.getString("d_area")),
					rs.getInt("d_stock"));
		}
	}
}
